var a = 5;
var b = 10;
var c = 20; 
var x = true;
var z = false;
var name = prompt("What is your name?");
var message = "Hello, ";
alert(message + name);