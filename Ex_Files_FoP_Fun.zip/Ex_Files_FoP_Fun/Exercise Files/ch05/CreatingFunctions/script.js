var a = 5;
var b = 10;
var c = 20;
var d = a + b + c;
alert("The value of d is: " + d );



