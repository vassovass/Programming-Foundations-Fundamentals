var headline = document.getElementById("mainHeading");
headline.innerHTML = "Wow! A new headline!";






