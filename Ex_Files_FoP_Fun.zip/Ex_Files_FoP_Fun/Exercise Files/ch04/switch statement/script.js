var grade = "Premium";

if ( grade === "Regular") {
     alert("It's $3.15");
}
if ( grade === "Premium") {
     alert("It's $3.35");
}
if ( grade === "Diesel") {
     alert("It's $3.47");
}