var a = 5;
var b = 10;

if ( a < b ) {
   alert("Yes, a is less than b");
}

if ( a == b ) {
   alert("Yes, a is equal to b");
}